import numpy as np
import sys, os

T = np.array([
    [0.3536, 0.3536, 0.3536, 0.3536, 0.3536, 0.3536, 0.3536, 0.3536],
    [0.4904, 0.4157, 0.2778, 0.0975,-0.0975,-0.2778,-0.4157,-0.4904],
    [0.4619, 0.1913,-0.1913,-0.4619,-0.4619,-0.1913, 0.1913, 0.4619],
    [0.4157,-0.0975,-0.4904,-0.2778, 0.2778, 0.4904, 0.0975,-0.4157],
    [0.3536,-0.3536,-0.3536, 0.3536, 0.3536,-0.3536,-0.3536, 0.3536],
    [0.2778,-0.4904, 0.0975, 0.4157,-0.4157,-0.0975, 0.4904,-0.2778],
    [0.1913,-0.4619, 0.4619,-0.1913,-0.1913, 0.4619,-0.4619, 0.1913],
    [0.0975,-0.2778, 0.4157,-0.4904, 0.4904,-0.4157, 0.2778,-0.0975]
])

Q_Y = np.array([
    [16,11,10,16,24,40,51,61],
    [12,12,14,19,26,58,60,55],
    [14,13,16,24,40,57,69,56],
    [14,17,22,29,51,87,80,62],
    [18,22,37,56,68,109,103,77],
    [24,35,55,64,81,104,113,92],
    [49,64,78,87,103,121,120,101],
    [72,92,95,98,112,100,103,99]
])

def text_to_bits(text):
    bits = []
    for ch in text + '\x00':
        for b in format(ord(ch), '08b'):
            bits.append(int(b))
    return bits

def embed_lsb(matrix_path, message):
    gray = np.loadtxt(matrix_path, dtype=np.float64)
    H, W = gray.shape
    bits = text_to_bits(message)
    bit_idx = 0
    stego = gray.copy()

    for r in range(0, H - 7, 8):
        for c in range(0, W - 7, 8):
            if bit_idx >= len(bits):
                break
            block = gray[r:r+8, c:c+8]
            dct_b = np.dot(np.dot(T, block - 128), T.T)
            q_b   = np.round(dct_b / Q_Y).astype(int)
            # Nhung vao he so tan so cao nhat [7][7]
            coef = q_b[7][7]
            q_b[7][7] = (coef & ~1) | bits[bit_idx]
            bit_idx += 1
            dct_back = q_b.astype(np.float64) * Q_Y
            stego[r:r+8, c:c+8] = np.clip(
                np.round(np.dot(np.dot(T.T, dct_back), T)) + 128, 0, 255)

    os.makedirs("output", exist_ok=True)
    out = "output/stego_lsb.txt"
    np.savetxt(out, stego, fmt="%d")
    with open(out, 'a') as f:
        f.write(f"\n# LSB_DONE bits={bit_idx}\n")
    print(f"[LSB-DCT] Nhung {bit_idx} bit vao '{out}'")
    print(f"[LSB-DCT] Vi tri nhung: he so [7][7] moi khoi 8x8")

if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Cu phap: python3 embed_lsb.py <matrix.txt> <message>")
        sys.exit(1)
    embed_lsb(sys.argv[1], sys.argv[2])
