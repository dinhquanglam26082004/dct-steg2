import numpy as np
import math, os

def psnr(orig, stego):
    mse = np.mean((orig.astype(float) - stego.astype(float)) ** 2)
    return 999.0 if mse == 0 else 20 * math.log10(255.0 / math.sqrt(mse))

def load_matrix(path):
    lines = [l for l in open(path) if not l.startswith('#')]
    return np.array([[float(x) for x in l.split()]
                     for l in lines if l.strip()])

orig = np.loadtxt("image_matrix.txt", dtype=np.float64)

methods = {
    "LSB-DCT": {
        "file"  : "output/stego_lsb.txt",
        "vitri" : "He so [7][7] - tan so cao nhat moi khoi",
        "uu"    : "Don gian, de cai dat",
        "nhuoc" : "De bi phat hien, chi giau 1 bit/khoi",
    },
    "JSteg": {
        "file"  : "output/stego_jsteg.txt",
        "vitri" : "He so AC != 0, !=+/-1 (nhieu vi tri hon)",
        "uu"    : "Dung luong cao, bo qua he so de lo",
        "nhuoc" : "Van co dau hieu thong ke bat thuong",
    },
}

print("=" * 60)
print("   SO SANH 2 PHUONG PHAP GIAU TIN MIEN TAN SO DCT")
print("=" * 60)

report_lines = [
    "SO SANH 2 PHUONG PHAP GIAU TIN MIEN TAN SO DCT",
    "",
    f"{'Phuong phap':<10} {'PSNR(dB)':>10} {'MSE':>10}",
    "-" * 60,
]

for name, info in methods.items():
    if not os.path.exists(info["file"]):
        print(f"[!] Chua co '{info['file']}' — chay embed truoc!")
        continue
    stego = load_matrix(info["file"])
    h = min(orig.shape[0], stego.shape[0])
    w = min(orig.shape[1], stego.shape[1])
    p   = psnr(orig[:h, :w], stego[:h, :w])
    mse = np.mean((orig[:h, :w] - stego[:h, :w]) ** 2)

    print(f"\n--- {name} ---")
    print(f"  PSNR      : {p:.4f} dB")
    print(f"  MSE       : {mse:.4f}")
    print(f"  Vi tri    : {info['vitri']}")
    print(f"  Uu diem   : {info['uu']}")
    print(f"  Nhuoc diem: {info['nhuoc']}")

    report_lines.append(f"{name:<10} {p:>10.4f} {mse:>10.4f}")

report_lines += [
    "",
    "NHAN XET:",
    "  Chat luong anh (PSNR): JSteg >= LSB-DCT",
    "  Dung luong giau       : JSteg >> LSB-DCT",
    "  Kha nang phat hien    : JSteg kho bi phat hien hon",
]

os.makedirs("output", exist_ok=True)
with open("output/report.txt", "w") as f:
    f.write("\n".join(report_lines))

print("\n" + "=" * 60)
print("Bao cao da luu: output/report.txt")
print("Xem: cat output/report.txt")
