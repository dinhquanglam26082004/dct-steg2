#!/bin/bash
mkdir -p /home/ubuntu/output
chmod +x /home/ubuntu/preprocessor/*.py
chmod +x /home/ubuntu/method1_lsb_dct/*.py
chmod +x /home/ubuntu/method2_jsteg/*.py
chmod +x /home/ubuntu/compare/*.py
