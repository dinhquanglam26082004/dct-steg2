import numpy as np
import sys

T = np.array([
    [0.3536, 0.3536, 0.3536, 0.3536, 0.3536, 0.3536, 0.3536, 0.3536],
    [0.4904, 0.4157, 0.2778, 0.0975,-0.0975,-0.2778,-0.4157,-0.4904],
    [0.4619, 0.1913,-0.1913,-0.4619,-0.4619,-0.1913, 0.1913, 0.4619],
    [0.4157,-0.0975,-0.4904,-0.2778, 0.2778, 0.4904, 0.0975,-0.4157],
    [0.3536,-0.3536,-0.3536, 0.3536, 0.3536,-0.3536,-0.3536, 0.3536],
    [0.2778,-0.4904, 0.0975, 0.4157,-0.4157,-0.0975, 0.4904,-0.2778],
    [0.1913,-0.4619, 0.4619,-0.1913,-0.1913, 0.4619,-0.4619, 0.1913],
    [0.0975,-0.2778, 0.4157,-0.4904, 0.4904,-0.4157, 0.2778,-0.0975]
])

Q_Y = np.array([
    [16,11,10,16,24,40,51,61],
    [12,12,14,19,26,58,60,55],
    [14,13,16,24,40,57,69,56],
    [14,17,22,29,51,87,80,62],
    [18,22,37,56,68,109,103,77],
    [24,35,55,64,81,104,113,92],
    [49,64,78,87,103,121,120,101],
    [72,92,95,98,112,100,103,99]
])

def bits_to_text(bits):
    chars = []
    for i in range(0, len(bits) - 7, 8):
        byte = int(''.join(map(str, bits[i:i+8])), 2)
        if byte == 0:
            break
        chars.append(chr(byte))
    return ''.join(chars)

def extract_jsteg(stego_path):
    lines = [l for l in open(stego_path) if not l.startswith('#')]
    stego = np.array([[float(x) for x in l.split()]
                      for l in lines if l.strip()])
    H, W = stego.shape
    bits = []
    for r in range(0, H - 7, 8):
        for c in range(0, W - 7, 8):
            block = stego[r:r+8, c:c+8]
            dct_b = np.dot(np.dot(T, block - 128), T.T)
            q_b   = np.round(dct_b / Q_Y).astype(int)
            for i in range(8):
                for j in range(8):
                    if i == 0 and j == 0:
                        continue
                    coef = q_b[i][j]
                    if coef in (0, 1, -1):
                        continue
                    bits.append(abs(coef) & 1)
    msg = bits_to_text(bits)
    print(f"[JSteg] Trich xuat: '{msg}'")

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Cu phap: python3 extract_jsteg.py <stego.txt>")
        sys.exit(1)
    extract_jsteg(sys.argv[1])
