from PIL import Image
import numpy as np
import sys

def image_to_matrix(input_path, output_txt="image_matrix.txt"):
    image = Image.open(input_path).convert("L")
    w, h = image.size
    pad_w = (8 - w % 8) % 8
    pad_h = (8 - h % 8) % 8
    arr = np.zeros((h + pad_h, w + pad_w), dtype=np.uint8)
    arr[:h, :w] = np.array(image)
    np.savetxt(output_txt, arr, fmt="%d")
    print(f"Luu ma tran thanh cong: '{output_txt}'  ({h}x{w} pixel)")

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Cu phap: python3 create_img_matrix.py <img_gray.png>")
        sys.exit(1)
    image_to_matrix(sys.argv[1])
