import sys
from PIL import Image

def resize_image(input_path, output_path="img_gray.png", size=(512, 512)):
    try:
        img = Image.open(input_path).convert("L").resize(size)
        img.save(output_path, format="PNG")
        print(f"Tao anh xam thanh cong: {output_path}")
    except Exception as e:
        print(f"Loi: {e}")

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Cu phap: python3 create_gray_img.py <input.png>")
        sys.exit(1)
    resize_image(sys.argv[1])
